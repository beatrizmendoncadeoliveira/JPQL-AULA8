package br.com.fiap.dao;

import br.com.fiap.entity.Transporte;

public interface TransporteDAO extends GenericDAO<Transporte,Integer>{

}
