package br.com.fiap.dao;

import br.com.fiap.entity.Endereco;

public interface EnderecoDAO extends GenericDAO<Endereco,Integer>{

}
